aclocal
autoconf
automake -a
#./configure --enable-debug
