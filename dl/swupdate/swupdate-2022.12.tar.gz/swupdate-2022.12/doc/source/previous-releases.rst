.. SPDX-FileCopyrightText: 2013-2021 Stefano Babic <sbabic@denx.de>
.. SPDX-License-Identifier: GPL-2.0-only

===================================
Documentation for previous releases
===================================

- `2021.11 <./2021.11/index.html>`_
- `2021.04 <./2021.04/index.html>`_
- `2020.11 <./2020.11/index.html>`_
- `2020.04 <./2020.04/index.html>`_
- `2019.11 <./2019.11/index.html>`_
- `2019.04 <./2019.04/index.html>`_
- `2018.11 <./2018.11/index.html>`_
