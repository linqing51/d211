// SPDX-FileCopyrightText: 2018 Stefano Babic <sbabic@denx.de>
//
// SPDX-License-Identifier: LGPL-2.1-or-later

#include <../corelib/lua_compat.c>
