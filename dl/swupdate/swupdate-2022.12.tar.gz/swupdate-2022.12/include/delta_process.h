/*
 * (C) Copyright 2021
 * Stefano Babic, sbabic@denx.de.
 *
 * SPDX-License-Identifier:     GPL-2.0-only
 */

#pragma once

extern int start_delta_downloader(const char *fname, int argc, char *argv[]);
