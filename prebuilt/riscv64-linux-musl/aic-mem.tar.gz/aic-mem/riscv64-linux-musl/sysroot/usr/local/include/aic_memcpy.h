/*
 * Copyright (C) 2023-2024 Artinchip Technology Co., Ltd.
 * Authors:  ArtInChip
 */

#ifndef _AIC_MEMCPY_H_
#define _AIC_MEMCPY_H_

#ifdef __cplusplus
extern "C" {
#endif
#include <stddef.h>

void * aic_memcpy(void *dst, const void *src, size_t count);

void * aic_dmabuf_memcpy(void *dst, const void *src, size_t count);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* _AIC_MEMCPY_H_ */
